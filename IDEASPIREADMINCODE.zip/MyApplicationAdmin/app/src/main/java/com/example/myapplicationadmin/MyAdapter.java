package com.example.myapplicationadmin;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private Context context;
    private List<DataClass> dataList;

    String CardName;

    public MyAdapter(Context context, List<DataClass> dataList , String CradName) {
        this.context = context;
        this.dataList = dataList;
        this.CardName = CradName;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.project_item_list, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.recTitle.setText(dataList.get(position).getProjectTitle());
        holder.recAuthorname.setText(dataList.get(position).getAuthorName());
        String rate = String.valueOf(dataList.get(position).getRating());
        holder.recRating.setText(rate);

      holder.recCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Project_idea_Details.class);
                intent.putExtra("projectImage", dataList.get(holder.getAdapterPosition()).getImageuri());
                intent.putExtra("projectAuthor", dataList.get(holder.getAdapterPosition()).getAuthorName());
                intent.putExtra("projectTitle", dataList.get(holder.getAdapterPosition()).getProjectTitle());
                intent.putExtra("projectDescription", dataList.get(holder.getAdapterPosition()).getProjectDescription());
                intent.putExtra("basepaper1", dataList.get(holder.getAdapterPosition()).getResearchpaperLink1());
                intent.putExtra("basepaper2",dataList.get(holder.getAdapterPosition()).getResearchpaperLink2());
                intent.putExtra("pptLink", dataList.get(holder.getAdapterPosition()).getPptLink());
                intent.putExtra("reportLink", dataList.get(holder.getAdapterPosition()).getReportLink());
                intent.putExtra("codeLink", dataList.get(holder.getAdapterPosition()).getCodeLink());
                intent.putExtra("CardName",CardName);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<DataClass> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }
}

class MyViewHolder extends RecyclerView.ViewHolder{

    ImageView recImage;
    TextView recTitle, recAuthorname, recRating;
    CardView recCard;

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);


        recCard = itemView.findViewById(R.id.recCard);
        recAuthorname = itemView.findViewById(R.id.recAuthorname);
        recRating = itemView.findViewById(R.id.recRating);
        recTitle = itemView.findViewById(R.id.recTitle);
    }
}