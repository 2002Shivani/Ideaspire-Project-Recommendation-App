package com.example.myapplicationadmin;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapterCompany extends RecyclerView.Adapter<MyViewHolderCompany> {

    private Context context;
    private List<CompanyDataClass> dataList;

    String CardName;

    public MyAdapterCompany(Context context, List<CompanyDataClass> dataList) {
        this.context = context;
        this.dataList = dataList;

    }

    @NonNull
    @Override
    public MyViewHolderCompany onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.company_list_layout, parent, false);
        return new MyViewHolderCompany(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderCompany holder, int position) {
        Glide.with(context).load(dataList.get(position).getDataImage()).into(holder.recImageCom);
        holder.recTitleCom.setText(dataList.get(position).getDataTitle());
        holder.recOwnerCom.setText(dataList.get(position).getDataOwner());


        holder.recCardCom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Company_details_show.class);
                intent.putExtra("ImageCom", dataList.get(holder.getAdapterPosition()).getDataImage());
                intent.putExtra("OwnerCom", dataList.get(holder.getAdapterPosition()).getDataOwner());
                intent.putExtra("SummaryCom", dataList.get(holder.getAdapterPosition()).getDataSummary());
                intent.putExtra("TitleCom", dataList.get(holder.getAdapterPosition()).getDataTitle());
                intent.putExtra("ProjectCom", dataList.get(holder.getAdapterPosition()).getDataProject());
                intent.putExtra("MobileCom", dataList.get(holder.getAdapterPosition()).getDataNumber());
                intent.putExtra("Key",dataList.get(holder.getAdapterPosition()).getKey());
                intent.putExtra("EmailCom",dataList.get(holder.getAdapterPosition()).getDataEmail());
                intent.putExtra("Service", dataList.get(holder.getAdapterPosition()).getDataService());
                intent.putExtra("location", dataList.get(holder.getAdapterPosition()).getLocation());


                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<CompanyDataClass> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }
}

class MyViewHolderCompany extends RecyclerView.ViewHolder{

    ImageView recImageCom;
    TextView recTitleCom, recOwnerCom, recRatingCom;
    CardView recCardCom;

    public MyViewHolderCompany(@NonNull View itemView) {
        super(itemView);

        recImageCom = itemView.findViewById(R.id.recImageCom);
        recCardCom = itemView.findViewById(R.id.recCardCom);
        recOwnerCom = itemView.findViewById(R.id.recOwnerName);

        recTitleCom = itemView.findViewById(R.id.recTitleCom);
    }
}