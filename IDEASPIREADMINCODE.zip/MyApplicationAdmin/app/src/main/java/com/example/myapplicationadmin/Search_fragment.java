package com.example.myapplicationadmin;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Search_fragment extends Fragment {


 TextView chatResponse , userQuerySend;
 ProgressBar loading ;
 ImageButton sendData , deleteData;
 EditText userQuery;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_search_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


            chatResponse = (TextView) view.findViewById(R.id.chatResponse);
          userQuerySend = (TextView) view.findViewById(R.id.userQuery);
            userQuery = (EditText) view.findViewById(R.id.userInputPrompt);
            sendData = (ImageButton) view.findViewById(R.id.sendChat);
            deleteData =(ImageButton) view.findViewById(R.id.deleteChat);
            loading =(ProgressBar)view.findViewById(R.id.loadingData);


            deleteData.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    chatResponse.setText("");
                    chatResponse.setVisibility(View.GONE);
                    userQuerySend.setVisibility(View.GONE);
                }
            });

            sendData.setOnClickListener(view1 -> {
                GeminiPro model = new GeminiPro();

                String query = userQuery.getText().toString();
                loading.setVisibility(View.VISIBLE);

                chatResponse.setText("");
                userQuery.setText("");
                userQuerySend.setVisibility(View.VISIBLE);
                userQuerySend.setText(query);

                model.getResponse(query, new ResponseCallback() {
                    @Override
                    public void onResponse(String response) {
                        chatResponse.setVisibility(View.VISIBLE);
                        chatResponse.setText(response);
                        Linkify.addLinks(chatResponse,Linkify.WEB_URLS);
                        loading.setVisibility(View.GONE);

                    }

                    @Override
                    public void onError(Throwable t) {
                        Toast.makeText(getActivity(), "Error: " , Toast.LENGTH_LONG).show();
                        loading.setVisibility(View.GONE);
                    }
                });


        });

    }
}