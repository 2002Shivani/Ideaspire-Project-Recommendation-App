package com.example.myapplicationadmin;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Profile extends Fragment {
    DatabaseReference reference;
    String username = "";
    public static  final String USERNAME = "username_args";

    public  static  Profile getInstance(String username ){
        Profile profileData = new Profile();
        Bundle bundle = new Bundle();
        bundle.putString(USERNAME,username);
        profileData.setArguments(bundle);
        return profileData;
    }
    CardView projectTotal , categoryTotal , userTotal , requestProjectTotal;
    TextView admintext , usertext , categoryText , requestText , AdminName;
    View view;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

     view = inflater.inflate(R.layout.fragment_profile, container, false);


        if (getArguments() != null) {

            username = getArguments().getString(USERNAME);

        }

           projectTotal  =(CardView)view.findViewById(R.id.card1);
                categoryTotal =(CardView)view.findViewById(R.id.card2);
                userTotal =(CardView)view.findViewById(R.id.card3);
                requestProjectTotal =(CardView)view.findViewById(R.id.card4);
                AdminName =(TextView)view.findViewById(R.id.adminName);
            AdminName.setText("Admin Profile");
            admintext = (TextView)view.findViewById(R.id.projectNumber);
            usertext =(TextView)view.findViewById(R.id.userNumber);
            categoryText =(TextView)view.findViewById(R.id.categoryNumber);
            requestText= (TextView)view.findViewById(R.id.requestedprojectNumber);

        AdminName.setText(username);


        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Admins");

        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();
                // Display or use the count as needed
                String countS = String.valueOf(count);
                admintext.setText(countS);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
            }
        });

        DatabaseReference databaseRef2 = FirebaseDatabase.getInstance().getReference("Users");

        databaseRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();
                // Display or use the count as needed
                String countS = String.valueOf(count);
                usertext.setText(countS);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
            }
        });


        DatabaseReference databaseRef3 = FirebaseDatabase.getInstance().getReference("Domain Database");

        databaseRef3.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();
                // Display or use the count as needed
                String countS = String.valueOf(count);
                categoryText.setText(countS);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
            }
        });


        DatabaseReference databaseRef4 = FirebaseDatabase.getInstance().getReference("Request Project Data");

        databaseRef4.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();
                // Display or use the count as needed
                String countS = String.valueOf(count);
                requestText.setText(countS);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
            }
        });

requestProjectTotal.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(getActivity(), RequestedProjectDataList.class);


        startActivity(intent);

    }
});













        return view;



    }





    }


