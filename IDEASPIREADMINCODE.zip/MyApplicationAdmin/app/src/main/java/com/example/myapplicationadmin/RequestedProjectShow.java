package com.example.myapplicationadmin;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Locale;

public class RequestedProjectShow extends AppCompatActivity {
    TextView CategoryDomain , projectTitleShow ,projectAuthorShow, projectDescriptionShow, baseStatus , reportStatus , pptStatus, codeStatus;
    ImageView projectImageShow;
    MaterialButton deleteProject , AcceptProject;
    float rating=0.0f;
    String key = "" ;
    String  available = "Available" , notAvaliable = "Not Avaliable";
    String imageUrl = "" , pptUrl = "" , reportUrl = "",codeUrl = "" , baseUrl_1 = "" , baseUrl_2="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requested_project_show);

        projectTitleShow  = findViewById(R.id.projectTitleShow);
        projectAuthorShow= findViewById(R.id.projectAuthorShow);
        projectDescriptionShow= findViewById(R.id.projectDescriptionShow);
        baseStatus = findViewById(R.id.basePaper);
        reportStatus = findViewById(R.id.reportStatus);
        pptStatus= findViewById(R.id.pptStatus);
        CategoryDomain= findViewById(R.id.Category);
        codeStatus= findViewById(R.id.codeStatus);
        deleteProject = findViewById(R.id.rejectProjectBtn);
        AcceptProject = findViewById(R.id.editProjectBtn);
        Bundle bundle = getIntent().getExtras();

        if (bundle != null){

            CategoryDomain.setText(bundle.getString("CardName"));
            projectTitleShow.setText(bundle.getString("projectTitle"));
            projectAuthorShow.setText(bundle.getString("projectAuthor"));
            projectDescriptionShow.setText(bundle.getString("projectDescription"));
            key = bundle.getString("Key");
            imageUrl = bundle.getString("projectImage");
            pptUrl = bundle.getString("pptLink");
            reportUrl = bundle.getString("reportLink");
            codeUrl = bundle.getString("codeLink");
            baseUrl_1  = bundle.getString("basepaper1");
            baseUrl_2  = bundle.getString("basepaper2");


            if(pptUrl==null|| pptUrl.equals("NA")){
                pptStatus.setText(notAvaliable);
            }else {
                pptStatus.setText(available);
                pptStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        AlertDialog.Builder builder = new AlertDialog.Builder(RequestedProjectShow.this);
                        builder.setMessage("Download PPT?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(pptUrl);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();


                    }
                });
            }

            if(reportUrl==null|| reportUrl.equals("NA")){
                reportStatus.setText(notAvaliable);
            }else {
                reportStatus.setText(available);
                reportStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(RequestedProjectShow.this);
                        builder.setMessage("Download Report?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(reportUrl);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();

                    }
                });
            }


            if(codeUrl==null|| codeUrl.equals("NA")){
                codeStatus.setText(notAvaliable);
            }else {
                codeStatus.setText(available);
                codeStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        AlertDialog.Builder builder = new AlertDialog.Builder(RequestedProjectShow.this);
                        builder.setMessage("Download Source code?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(codeUrl);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();

                    }
                });
            }


            if(baseUrl_1==null|| baseUrl_1.equals("NA")){
                baseStatus.setText(notAvaliable);
            }else {
                baseStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(RequestedProjectShow.this);
                        builder.setMessage("Download Base Paper?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(baseUrl_1);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();
                    }
                });
            }

        }

        AcceptProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(RequestedProjectShow.this);
                builder.setCancelable(false);
                builder.setView(R.layout.progress_layout);
                AlertDialog dialog = builder.create();
                dialog.show();

                String title = projectTitleShow.getText().toString();
                String author = projectAuthorShow.getText().toString();
                String description = projectDescriptionShow.getText().toString();
                String CategoryName = CategoryDomain.getText().toString();
                DataClass dataClass = new DataClass(title, description, author, imageUrl,reportUrl,codeUrl,pptUrl,baseUrl_1,rating);
                FirebaseDatabase.getInstance().getReference( CategoryName).child(title)
                        .setValue(dataClass).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(RequestedProjectShow.this, "Saved", Toast.LENGTH_SHORT).show();
                                    finish();
                                    dialog.dismiss();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(RequestedProjectShow.this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            }
                        });
            }
        });

        deleteProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(RequestedProjectShow.this);
                builder.setCancelable(false);
                builder.setView(R.layout.delete_progress);
                AlertDialog dialog = builder.create();
                dialog.show();
                String title = projectTitleShow.getText().toString();
                FirebaseDatabase.getInstance().getReference( "Request Project Data").child(title).removeValue();
                Toast.makeText(RequestedProjectShow.this, "Deleded", Toast.LENGTH_SHORT).show();
                finish();
                dialog.dismiss();


            }
        });

    }

    private void downloadFile(String url) {
        if (!TextUtils.isEmpty(url)) {

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        }
    }
}