package com.example.myapplicationadmin;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.myapplicationadmin.databinding.ActivityMainMenuBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

public class Idea_fragment extends Fragment {

    ActivityMainMenuBinding binding;
    FirebaseDatabase database;
    FirebaseStorage storage;
  Uri imageUri;
int i;
String imageURL;
    CircleImageView domainImage ;
    EditText domainName;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;
    FloatingActionButton addDomain;
    Button domainUploadBtn;
    Dialog uploadDialog;
    DomainAdapter domainAdapter;
    ArrayList<DomainDataUpload> datalist;
    RecyclerView domainRecycleView;
    View fetchImage ,view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

view = inflater.inflate(R.layout.fragment_idea_fragment, container, false);

        uploadDialog = new Dialog(getActivity());

        uploadDialog.setContentView(R.layout.item_add_category_dialog);
        if (uploadDialog.getWindow()!= null){
            uploadDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            uploadDialog.setCancelable(true);
        };


        domainImage = uploadDialog.findViewById(R.id.categoryImage);
        domainName = uploadDialog.findViewById(R.id.categoryName);
        domainUploadBtn = uploadDialog.findViewById(R.id.categoryUploadBtn);
        fetchImage = uploadDialog.findViewById(R.id.fetchimage);
        addDomain = ( FloatingActionButton) view.findViewById(R.id.addCategory);
        domainRecycleView = (RecyclerView)view.findViewById(R.id.CategoryItem);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        domainRecycleView.setLayoutManager(gridLayoutManager);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(false);
        builder.setView(R.layout.loading_progress);
        AlertDialog dialog = builder.create();
        dialog.show();
        datalist = new ArrayList<>();
        domainAdapter = new DomainAdapter(getActivity(), datalist);
        domainRecycleView.setAdapter(domainAdapter);
        databaseReference = FirebaseDatabase.getInstance().getReference("Domain Database");
        dialog.show();
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                datalist.clear();
                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    DomainDataUpload dataClass = itemSnapshot.getValue(DomainDataUpload.class);
                    dataClass.setKey(itemSnapshot.getKey());
                    datalist.add(dataClass);
                }
                domainAdapter.notifyDataSetChanged();
                dialog.dismiss();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
            }
        });





















        ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK){
                            Intent data = result.getData();
                            imageUri = data.getData();
                            domainImage.setImageURI(imageUri);
                        } else {
                            Toast.makeText(getActivity(), "No Image Selected", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
        domainImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent photoPicker = new Intent(Intent.ACTION_PICK);
                photoPicker.setType("image/*");
                activityResultLauncher.launch(photoPicker);
            }
        });

        domainUploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });

        addDomain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadDialog.show();
            }
        });


        return view;
    }

    private void saveData() {

        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Domain Images")
                .child(imageUri.getLastPathSegment());
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(false);
        builder.setView(R.layout.progress_layout);
        AlertDialog dialog = builder.create();
        dialog.show();
        storageReference.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                while (!uriTask.isComplete());
                Uri urlImage = uriTask.getResult();
                imageURL = urlImage.toString();
                uploadData();
                dialog.dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                dialog.dismiss();
            }
        });


    }

    private void uploadData() {

        String domainTitle = domainName.getText().toString();

        DomainDataUpload domainDataUpload = new DomainDataUpload(domainTitle,imageURL);

        FirebaseDatabase.getInstance().getReference("Domain Database").child(domainTitle)
                .setValue(domainDataUpload).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(getActivity(), "Saved", Toast.LENGTH_SHORT).show();

                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


}