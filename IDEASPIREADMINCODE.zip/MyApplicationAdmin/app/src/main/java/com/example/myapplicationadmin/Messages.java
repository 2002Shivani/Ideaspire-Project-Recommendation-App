package com.example.myapplicationadmin;

public class Messages {

    public  static String SENT_BY_ME = "Me";
    public  static String SENT_BY_Bot = "Bot";
    String message;
    String sendBy;

    public Messages(String message, String sendBy) {
        this.message = message;
        this.sendBy = sendBy;
    }

    public Messages() {
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSendBy() {
        return sendBy;
    }

    public void setSendBy(String sendBy) {
        this.sendBy = sendBy;
    }
}
