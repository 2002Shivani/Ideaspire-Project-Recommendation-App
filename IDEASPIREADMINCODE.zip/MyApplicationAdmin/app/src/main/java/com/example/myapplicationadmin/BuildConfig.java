package com.example.myapplicationadmin;

public class BuildConfig {
    public static String apiKey = "AIzaSyCRdEXwdFINsEbwRL36PrLKBziyI-eLre4";
}
