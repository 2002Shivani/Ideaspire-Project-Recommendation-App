package com.example.myapplicationadmin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Upload_data_activity extends AppCompatActivity {
    EditText editFullName, editEmail, editUsername, editMobile , editAbout;
    Button saveButton;


    String nameUser, emailUser, usernameUser, mobileUser , aboutUser;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_data);
            reference = FirebaseDatabase.getInstance().getReference("Users");

            editFullName = findViewById(R.id.userFullnameU);
            editEmail = findViewById(R.id.EmailU);
            editUsername = findViewById(R.id.userNameU);
            editMobile = findViewById(R.id.MobileU);
            editAbout = findViewById(R.id.aboutMe);
            saveButton = findViewById(R.id.updateButton);



            showData();
            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isNameChanged() || isMobileChanged() ||isAboutChanged() ||isUsernameChanged() || isEmailChanged()){
                        Toast.makeText(Upload_data_activity.this, "Saved", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(Upload_data_activity.this, "No Changes Found", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Upload_data_activity.this, Profile.class);

                    }

                }
            });
        }
        private boolean isNameChanged() {
            if (!nameUser.equals(editFullName.getText().toString())){
                reference.child(usernameUser).child("name").setValue(editFullName.getText().toString());
                nameUser = editFullName.getText().toString();
                return true;
            } else {
                return false;
            }
        }
        private boolean isEmailChanged() {
            if (!emailUser.equals(editEmail.getText().toString())){
                reference.child(usernameUser).child("email").setValue(editEmail.getText().toString());
                emailUser = editEmail.getText().toString();
                return true;
            } else {
                return false;
            }
        }



     private boolean isMobileChanged()  {
        if (!mobileUser.equals(editMobile.getText().toString())){
            reference.child(usernameUser).child("mobile").setValue(editMobile.getText().toString());
            mobileUser = editMobile.getText().toString();
            return true;
        } else {
            return false;
        }
    }
    private boolean isAboutChanged()  {
        if (!aboutUser.equals(editAbout.getText().toString())){
            reference.child(usernameUser).child("aboutme").setValue(editAbout.getText().toString());
            aboutUser = editAbout.getText().toString();
            return true;
        } else {
            return false;
        }
    }
    private boolean isUsernameChanged()  {
        if (!usernameUser.equals(editUsername.getText().toString())){
            reference.child(usernameUser).child("username").setValue(editEmail.getText().toString());
            usernameUser = editUsername.getText().toString();
            return true;
        } else {
            return false;
        }
    }



        public void showData(){
            Intent intent = getIntent();
            nameUser = intent.getStringExtra("Name");
            emailUser = intent.getStringExtra("Email");
            usernameUser = intent.getStringExtra("UserName");
            mobileUser =intent.getStringExtra("Mobile");
            aboutUser = intent.getStringExtra("Description");
            editFullName.setText(nameUser);
            editEmail.setText(emailUser);
            editUsername.setText(usernameUser);
            editAbout.setText(aboutUser);
            editMobile.setText(mobileUser);

        }
    }


