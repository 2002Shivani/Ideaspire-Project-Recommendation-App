package com.example.myapplicationadmin;

public class CompanyDataClass {

    private String  dataOwner;
    private String dataTitle;
    private String dataSummary;
    private String dataProject;
    private String dataService;
    private String dataEmail;
    private String dataNumber;
    private String dataImage;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    private String location;


    private float rating;


    public String getDataOwner() {
        return dataOwner;
    }

    public void setDataOwner(String dataOwner) {
        this.dataOwner = dataOwner;
    }

    public float getDataRating() {
        return rating;
    }
    private String key;
    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }

    public void setDataRating(float rating) {
        this.rating = rating;
    }

    public CompanyDataClass(String dataOwner , String dataTitle, String dataSummary, String dataProject, String dataService, String dataEmail, String dataNumber, String dataImage,String location) {
        this.dataTitle = dataTitle;
        this.dataSummary = dataSummary;
        this.dataProject = dataProject;
        this.dataService = dataService;
        this.dataEmail = dataEmail;
        this.dataNumber = dataNumber;
        this.dataImage = dataImage;
        this.dataOwner = dataOwner;
        this.location = location;
        this.key = key;

    }

    public CompanyDataClass() {
    }

    public String getDataTitle() {
        return dataTitle;
    }

    public void setDataTitle(String dataTitle) {
        this.dataTitle = dataTitle;
    }

    public String getDataSummary() {
        return dataSummary;
    }

    public void setDataSummary(String dataSummary) {
        this.dataSummary = dataSummary;
    }

    public String getDataProject() {
        return dataProject;
    }

    public void setDataProject(String dataProject) {
        this.dataProject = dataProject;
    }

    public String getDataService() {
        return dataService;
    }

    public void setDataService(String dataService) {
        this.dataService = dataService;
    }

    public String getDataEmail() {
        return dataEmail;
    }

    public void setDataEmail(String dataEmail) {
        this.dataEmail = dataEmail;
    }

    public String getDataNumber() {
        return dataNumber;
    }

    public void setDataNumber(String dataNumber) {
        this.dataNumber = dataNumber;
    }

    public String getDataImage() {
        return dataImage;
    }

    public void setDataImage(String dataImage) {
        this.dataImage = dataImage;
    }
}
