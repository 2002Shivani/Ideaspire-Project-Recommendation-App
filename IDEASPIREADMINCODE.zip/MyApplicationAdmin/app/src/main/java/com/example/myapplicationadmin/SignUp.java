package com.example.myapplicationadmin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {
 EditText  signUsername , signName , signEmail, signPassword , signMobile;
 TextView loginText;
 Button signUpButton;
 FirebaseDatabase database;
 DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        signUsername = findViewById(R.id.userName);
        signName = findViewById(R.id.signName);
        signEmail=  findViewById(R.id.signEmail);
        signPassword =findViewById(R.id.signPswrd);
        signMobile =findViewById(R.id.signMobile);
        loginText = findViewById(R.id.loginText);
        signUpButton = findViewById(R.id.signBtn);






        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                database = FirebaseDatabase.getInstance();

                reference = database.getReference("Admins");



                String username = signUsername.getText().toString();
                String name = signName.getText().toString();
                String email = signEmail.getText().toString();
                String password = signPassword.getText().toString();
                String mobile = signMobile.getText().toString();


                HelperClass helperCass = new HelperClass( username ,name , email, password, mobile);
                reference.child(username).setValue(helperCass);
                Toast.makeText(SignUp.this, "You Have sign up Successfully", Toast.LENGTH_SHORT).show();
                Intent intent  = new Intent(SignUp.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        loginText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(SignUp.this,LoginActivity.class);
                startActivity(intent);
                finish();

            }
        });


    }
}