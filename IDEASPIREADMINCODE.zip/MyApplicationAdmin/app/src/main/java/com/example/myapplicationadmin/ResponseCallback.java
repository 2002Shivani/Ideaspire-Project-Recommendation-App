package com.example.myapplicationadmin;

public interface ResponseCallback {
    void onResponse(String response);

    void onError(Throwable t);
}
