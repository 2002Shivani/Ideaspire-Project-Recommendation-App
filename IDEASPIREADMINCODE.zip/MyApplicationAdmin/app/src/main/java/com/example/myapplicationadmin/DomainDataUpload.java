package com.example.myapplicationadmin;

public class DomainDataUpload {

    private String DomainName , DomainImage , key;
        int TotalProjects;

    public DomainDataUpload() {
    }

    public int getTotalProjects() {
        return TotalProjects;
    }

    public void setTotalProjects(int totalProjects) {
        TotalProjects = totalProjects;
    }

    public DomainDataUpload(String domainName, String domainImage) {
        this.DomainName = domainName;
        this.DomainImage = domainImage;
        this.key = key;
        this.TotalProjects = TotalProjects;
    }

    public String getDomainName() {
        return DomainName;
    }

    public void setDomainName(String domainName) {
        DomainName = domainName;
    }

    public String getDomainImage() {
        return DomainImage;
    }

    public void setDomainImage(String domainImage) {
        DomainImage = domainImage;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
