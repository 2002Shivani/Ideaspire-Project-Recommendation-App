package com.example.myapplicationadmin;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapterRequested extends RecyclerView.Adapter<MyRequestedViewHolder> {

    private Context context;
    private List<RequestedProjectDataClass> dataList;

    String CardName;

    public MyAdapterRequested(Context context, List<RequestedProjectDataClass> dataList) {
        this.context = context;
        this.dataList = dataList;

    }

    @NonNull
    @Override
    public MyRequestedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.project_item_list, parent, false);
        return new MyRequestedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyRequestedViewHolder holder, int position) {

        holder.recTitle.setText(dataList.get(position).getProjectTitle());
        holder.recAuthorname.setText(dataList.get(position).getAuthorName());
        holder.recCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, RequestedProjectShow.class);
                intent.putExtra("projectImage", dataList.get(holder.getAdapterPosition()).getImageuri());
                intent.putExtra("projectAuthor", dataList.get(holder.getAdapterPosition()).getAuthorName());
                intent.putExtra("projectTitle", dataList.get(holder.getAdapterPosition()).getProjectTitle());
                intent.putExtra("projectDescription", dataList.get(holder.getAdapterPosition()).getProjectDescription());
                intent.putExtra("basepaper1", dataList.get(holder.getAdapterPosition()).getResearchpaperLink1());
                intent.putExtra("pptLink", dataList.get(holder.getAdapterPosition()).getPptLink());
                intent.putExtra("reportLink", dataList.get(holder.getAdapterPosition()).getReportLink());
                intent.putExtra("codeLink", dataList.get(holder.getAdapterPosition()).getCodeLink());
//
                intent.putExtra("Key",dataList.get(holder.getAdapterPosition()).getKey());
                intent.putExtra("CardName",dataList.get(holder.getAdapterPosition()).getCategory());


                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

}

class MyRequestedViewHolder extends RecyclerView.ViewHolder{

    ImageView recImage;
    TextView recTitle, recAuthorname, recRating;
    CardView recCard;

    public MyRequestedViewHolder(@NonNull View itemView) {
        super(itemView);


        recCard = itemView.findViewById(R.id.recCard);
        recAuthorname = itemView.findViewById(R.id.recAuthorname);
        recRating = itemView.findViewById(R.id.recRating);
        recTitle = itemView.findViewById(R.id.recTitle);
    }
}