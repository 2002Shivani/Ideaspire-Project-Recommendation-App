package com.example.myapplicationadmin;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class Home_fragment extends Fragment {
CardView searchCard , ideaCard , contractorCard;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home_fragment, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        searchCard = (CardView) view.findViewById(R.id.searchCard);
        ideaCard = (CardView)view.findViewById(R.id.ideaCard);
        contractorCard = (CardView)view.findViewById(R.id.contractorCard);



        searchCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Fragment fragment = new Search_fragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmenmentTransaction = fragmentManager.beginTransaction();
                fragmenmentTransaction.replace(R.id.home,fragment);
                fragmenmentTransaction.addToBackStack(null);
                fragmenmentTransaction.commit();
            }
        });
        ideaCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragment = new Idea_fragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmenmentTransaction = fragmentManager.beginTransaction();
                fragmenmentTransaction.replace(R.id.home,fragment);
                fragmenmentTransaction.addToBackStack(null);
                fragmenmentTransaction.commit();
            }
        });
        contractorCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragment = new Contractor();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmenmentTransaction = fragmentManager.beginTransaction();
                fragmenmentTransaction.replace(R.id.home,fragment);
                fragmenmentTransaction.addToBackStack(null);
                fragmenmentTransaction.commit();
            }
        });
    }
}