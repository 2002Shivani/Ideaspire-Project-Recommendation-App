package com.example.myapplication;

import static android.content.Intent.getIntent;
import static android.content.Intent.getIntentOld;
import static android.content.Intent.parseUri;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;


public class Profile extends Fragment {
    DatabaseReference reference;
    public static  final String USERNAME = "username_args";
    public static  final String NAME = "name_args";
    public static  final String ABOUTME = "about_me";


    public static  final String EMAIL = "email_args";
    public static  final String PHONE_NO = "phone_args";
    public static  final String USERTYPE = "usertype_args";
    public  static  Profile getInstance(String username , String name , String email , String  phone , String usertype ,String aboutme ){
        Profile profileData = new Profile();
        Bundle bundle = new Bundle();
        bundle.putString(USERNAME,username);
        bundle.putString(NAME,name);
        bundle.putString(EMAIL,email);
        bundle.putString(PHONE_NO,phone);
        bundle.putString(USERTYPE,usertype);
        bundle.putString(ABOUTME,aboutme);
        profileData.setArguments(bundle);
        return profileData;
    }
    Button editButton , logoutButton;
    TextView Profileusername , Profilename ,  ProfileEmail ,  ProfileMobile, ProfileuserType;
    String username = "";
    String fullname = "";
    String Email = "";
    String Phone_no = "";
    String userType = "" , aboutMeText="";
    TextView description;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        return inflater.inflate(R.layout.fragment_profile, container, false);


    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        if (getArguments() != null) {

            username = getArguments().getString(USERNAME);
            fullname = getArguments().getString(NAME);
            Email = getArguments().getString(EMAIL);
            Phone_no = getArguments().getString(PHONE_NO);
            userType = getArguments().getString(USERTYPE);
            aboutMeText  = getArguments().getString(ABOUTME);
            Log.d("msgUserName", "Profile  is " + username);
            Log.d("msgName", "Profile is " + fullname);
            Log.d("msgEmail", "Profile is " + Email);
            Log.d("msgMobile", "Profile is " + Phone_no);
            Log.d("msgType", "Profile is " + userType);
        }


        Profileusername = (TextView) view.findViewById(R.id.usernameProfile);
        Profilename = (TextView) view.findViewById(R.id.fullname);
        ProfileEmail = (TextView) view.findViewById(R.id.userEmail);
        ProfileMobile = (TextView) view.findViewById(R.id.userNumber);
        ProfileuserType = (TextView) view.findViewById(R.id.userType);
        description = (TextView) view.findViewById(R.id.userDescription);

        Profileusername.setText(username);
        Profilename.setText(fullname);
        ProfileEmail.setText(Email);
        ProfileMobile.setText(Phone_no);
        ProfileuserType.setText(userType);
        description.setText(aboutMeText);
        editButton = (Button) view.findViewById(R.id.editUser);
        logoutButton = (Button) view.findViewById(R.id.Logout);


        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), Upload_data_activity.class);
                intent.putExtra("UserName", username);
                intent.putExtra("Name", fullname);
                intent.putExtra("Email", Email);
                intent.putExtra ("Mobile", Phone_no);
                intent.putExtra ("UserType",  userType);
                intent.putExtra("About me",aboutMeText);
                getActivity().startActivity(intent);
            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), LoginActivity.class);
                getActivity().startActivity(intent);


            }
        });


        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");

        reference.child(username).child("name").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.getValue(String.class);
                if (name != null) {
                    Profilename.setText(name);
                } else {

                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        reference.child(username).child("username").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.getValue(String.class);
                if (name != null) {
                    Profileusername.setText(name);
                } else {

                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {


            }
        });




    }


}