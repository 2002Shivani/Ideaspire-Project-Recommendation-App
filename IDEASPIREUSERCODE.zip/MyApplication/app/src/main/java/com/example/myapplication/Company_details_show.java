package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.github.clans.fab.FloatingActionButton;
import com.google.android.material.button.MaterialButton;

public class Company_details_show extends AppCompatActivity {
    TextView CTitle, COwner, CServices , CEmail , CProjects, CSummary, Clocation , CProjectName;
    ImageView detailImage;

    String key = "";
    String imageUrl = "";
    MaterialButton requestEmail ;

    Button   saveRating;
    Dialog uploadRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_details_show);



        Intent getDataNameFromIdea  = getIntent();
        CTitle = findViewById(R.id.CtitleName);
        COwner = findViewById(R.id.COwnername);
        CServices = findViewById(R.id.CServices);
        CEmail = findViewById(R.id.CprofileEmail);
        CProjects = findViewById(R.id.CprojectNo);
        CSummary = findViewById(R.id.CSummry);
        Clocation = findViewById(R.id.CRating);
        detailImage=  findViewById(R.id.CprofileImg);
        CProjectName = findViewById(R.id.projectname);
        requestEmail = findViewById(R.id.requestEmail);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null){
         CTitle.setText(bundle.getString("TitleCom"));
            COwner.setText(bundle.getString("OwnerCom"));
            CServices.setText(bundle.getString("Service"));
            CEmail.setText(bundle.getString("EmailCom"));
            CProjects.setText(bundle.getString("ProjectCom"));
            CSummary.setText(bundle.getString("SummaryCom"));
            Clocation.setText(bundle.getString("location"));
            key = bundle.getString("Key");
            CProjectName.setText(bundle.getString("ProjectCom"));
            imageUrl = bundle.getString("ImageCom");
            Glide.with(this).load(bundle.getString("ImageCom")).into(detailImage);
        }



        requestEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail();
            }
        });
    }

    public void sendEmail() {

        String[] to = {CEmail.getText().toString()};

        String OwnerName = COwner.getText().toString();
        Intent mail = new Intent(Intent.ACTION_SEND);
        mail.setData(Uri.parse("mailto:"));
        mail.setType("text/plain");

        mail.putExtra(Intent.EXTRA_EMAIL, to);
        mail.putExtra(Intent.EXTRA_TEXT, "Dear "+OwnerName+",\n" +
                "\n" +
                "I hope this email finds you well. My name is [Your Name], and I am a student at [Your Institution/University], studying [Your Program/Major]. I am reaching out to inquire about the possibility of collaborating with your esteemed software company for the development of an academic project.\n" +
                "\n" +
                "The project I am working on is [brief description of the project]. It is a significant endeavor that requires specialized technical expertise, and after researching various options, I believe that your company's reputation for excellence in software development aligns perfectly with the requirements of this project. " );
        mail.putExtra(Intent.EXTRA_SUBJECT, "Request For Project Development By Ideaspire Client");

        startActivity(Intent.createChooser(mail, "mailto") );

    }
}