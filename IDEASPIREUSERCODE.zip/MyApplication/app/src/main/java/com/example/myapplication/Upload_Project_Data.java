package com.example.myapplication;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.DateFormat;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;

public class Upload_Project_Data extends AppCompatActivity {
    CircleImageView uploadImage;
    Button saveButton;
    ImageButton uploadPPTbtn, uploadReportbtn, uploadCodebtn, uploadBasebtn;
    EditText uploadCategory, uploadTopic, uploadDesc, uploadAuthor, uploadBasePaper_1, uploadReport, uploadPPT, uploadCode;
    String imageURL = "NA", reportUrl = "NA", pptUrl = "NA", codeUrl = "NA", baseUrl = "NA";
    Uri imageUri, baseuri, reportUri, pptUri, codeUri;
    float RatingInfo = 0.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_project_data);

        Intent getDataNameFromIdea = getIntent();
        String CardDataName = getDataNameFromIdea.getStringExtra("CardName");
        Log.d("CardName", CardDataName);

        uploadImage = findViewById(R.id.projectImage);
        uploadDesc = findViewById(R.id.projectDescription);
        uploadTopic = findViewById(R.id.projectTitle);
        uploadAuthor = findViewById(R.id.authorName);
        uploadReport = findViewById(R.id.report);
        uploadPPT = findViewById(R.id.ppt);
        uploadCode = findViewById(R.id.code);
        uploadBasePaper_1 = findViewById(R.id.base1);
        uploadCategory = findViewById(R.id.Category);
        uploadBasebtn = findViewById(R.id.base1Upload);
        uploadReportbtn = findViewById(R.id.docUpload);
        uploadPPTbtn = findViewById(R.id.pptUpload);
        uploadCodebtn = findViewById(R.id.codeUpload);
        saveButton = findViewById(R.id.sendToServer);

        ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        imageUri = data.getData();
                        uploadImage.setImageURI(imageUri);
                    } else {
                        Toast.makeText(Upload_Project_Data.this, "No Image Selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        uploadImage.setOnClickListener(view -> {
            Intent photoPicker = new Intent(Intent.ACTION_PICK);
            photoPicker.setType("image/*");
            activityResultLauncher.launch(photoPicker);
        });

        // Report
        ActivityResultLauncher<Intent> activityResultLauncher2 = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        reportUri = data.getData();
                        uploadReport.setText(reportUri.toString());
                    } else {
                        reportUrl = "NA";
                        Toast.makeText(Upload_Project_Data.this, "No Report Selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        uploadReportbtn.setOnClickListener(view -> {
            Intent filePicker = new Intent(Intent.ACTION_GET_CONTENT);
            filePicker.setType("*/*");
            activityResultLauncher2.launch(filePicker);
        });

        // PPT
        ActivityResultLauncher<Intent> activityResultLauncher3 = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        pptUri = data.getData();
                        uploadPPT.setText(pptUri.toString());
                    } else {
                        pptUrl = "NA";
                        Toast.makeText(Upload_Project_Data.this, "No PPT Selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        uploadPPTbtn.setOnClickListener(view -> {
            Intent filePicker = new Intent(Intent.ACTION_GET_CONTENT);
            filePicker.setType("*/*");
            activityResultLauncher3.launch(filePicker);
        });

        // Code
        ActivityResultLauncher<Intent> activityResultLauncher4 = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        codeUri = data.getData();
                        uploadCode.setText(codeUri.toString());
                    } else {
                        codeUrl = "NA";
                        Toast.makeText(Upload_Project_Data.this, "No Code Selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        uploadCodebtn.setOnClickListener(view -> {
            Intent filePicker = new Intent(Intent.ACTION_GET_CONTENT);
            filePicker.setType("*/*");
            activityResultLauncher4.launch(filePicker);
        });

        // Base Paper
        ActivityResultLauncher<Intent> activityResultLauncher5 = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        baseuri = data.getData();
                        uploadBasePaper_1.setText(baseuri.toString());
                    } else {
                        baseUrl = "NA";
                        Toast.makeText(Upload_Project_Data.this, "No Base Paper Selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        uploadBasebtn.setOnClickListener(view -> {
            Intent filePicker = new Intent(Intent.ACTION_GET_CONTENT);
            filePicker.setType("*/*");
            activityResultLauncher5.launch(filePicker);
        });

        saveButton.setOnClickListener(view -> saveData(CardDataName));
    }

    public void saveData(String CardDataName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Upload_Project_Data.this);
        builder.setCancelable(false);
        builder.setView(R.layout.progress_layout);
        AlertDialog dialog = builder.create();
        dialog.show();

        if (imageUri != null) {
            uploadFile(imageUri, "Image", uri -> {
                imageURL = uri.toString();
                checkCompletion(dialog, CardDataName);
            }, dialog);
        } else {
            checkCompletion(dialog, CardDataName);
        }

        if (reportUri != null) {
            uploadFile(reportUri, "files", uri -> {
                reportUrl = uri.toString();
                checkCompletion(dialog, CardDataName);
            }, dialog);
        } else {
            checkCompletion(dialog, CardDataName);
        }

        if (pptUri != null) {
            uploadFile(pptUri, "files", uri -> {
                pptUrl = uri.toString();
                checkCompletion(dialog, CardDataName);
            }, dialog);
        } else {
            checkCompletion(dialog, CardDataName);
        }

        if (codeUri != null) {
            uploadFile(codeUri, "files", uri -> {
                codeUrl = uri.toString();
                checkCompletion(dialog, CardDataName);
            }, dialog);
        } else {
            checkCompletion(dialog, CardDataName);
        }

        if (baseuri != null) {
            uploadFile(baseuri, "files", uri -> {
                baseUrl = uri.toString();
                checkCompletion(dialog, CardDataName);
            }, dialog);
        } else {
            checkCompletion(dialog, CardDataName);
        }
    }

    private int completedTasks = 0;
    private static final int TOTAL_TASKS = 5;

    private synchronized void checkCompletion(AlertDialog dialog, String CardDataName) {
        completedTasks++;
        if (completedTasks == TOTAL_TASKS) {
            uploadData(CardDataName);
            dialog.dismiss();
        }
    }

    private void uploadFile(Uri fileUri, String folder, OnSuccessListener<Uri> onSuccessListener, AlertDialog dialog) {
        if (fileUri == null) {
            onSuccessListener.onSuccess(Uri.parse("NA"));
            return;
        }

        String fileName = UUID.randomUUID().toString() + "_" + fileUri.getLastPathSegment();
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(folder).child(fileName);

        storageReference.putFile(fileUri).addOnSuccessListener(taskSnapshot -> {
            Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
            uriTask.addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();
                    onSuccessListener.onSuccess(downloadUri);
                }
            });
        }).addOnFailureListener(e -> {
            dialog.dismiss();
            Toast.makeText(Upload_Project_Data.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    public void uploadData(String CardDataName) {
        String title = uploadTopic.getText().toString();
        String desc = uploadDesc.getText().toString();
        String lang = uploadAuthor.getText().toString();
        String category = uploadCategory.getText().toString();

        ProjectDataClass dataClass = new ProjectDataClass(title, desc, lang, category, imageURL, reportUrl, codeUrl, pptUrl, baseUrl, RatingInfo);
        String currentDate = DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());

        FirebaseDatabase.getInstance().getReference("Request Project Data").child(title)
                .setValue(dataClass)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(Upload_Project_Data.this, "Saved", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(Upload_Project_Data.this, "Failed to save data", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
