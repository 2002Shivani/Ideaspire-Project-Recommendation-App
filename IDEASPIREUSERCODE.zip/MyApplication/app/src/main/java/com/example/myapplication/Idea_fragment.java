package com.example.myapplication;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Idea_fragment extends Fragment {
    DatabaseReference databaseReference;
    ValueEventListener eventListener;
    DomainAdapter domainAdapter;
    ArrayList<DomainDataUpload> datalist;
    RecyclerView domainRecycleView;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_idea_fragment, container, false);


        domainRecycleView = (RecyclerView)view.findViewById(R.id.CategoryItem);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        domainRecycleView.setLayoutManager(gridLayoutManager);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(false);
        builder.setView(R.layout.loading_progress);
        AlertDialog dialog = builder.create();
        dialog.show();
        datalist = new ArrayList<>();
        domainAdapter = new DomainAdapter(getActivity(), datalist);
        domainRecycleView.setAdapter(domainAdapter);
        databaseReference = FirebaseDatabase.getInstance().getReference("Domain Database");
        dialog.show();
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                datalist.clear();
                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    DomainDataUpload dataClass = itemSnapshot.getValue(DomainDataUpload.class);
                    dataClass.setKey(itemSnapshot.getKey());
                    datalist.add(dataClass);
                }
                domainAdapter.notifyDataSetChanged();
                dialog.dismiss();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
            }
        });
















        return view;


    }

}