package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoginAndRegister extends AppCompatActivity {

    Button login1 , login2 , signup1 , signup2;
    CardView loginCard , signupCard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_and_register);

        loginCard = (CardView) findViewById(R.id.loginCard);
        signupCard = (CardView) findViewById(R.id.signupCard);
        login1 = (Button) findViewById(R.id.loginbtn1);
        login2 = (Button) findViewById(R.id.loginbtn2);
        signup1 =(Button) findViewById(R.id.signupbtn1);
        signup2 =(Button) findViewById(R.id.signupbtn2);
    }

    public void login(View view){
        loginCard.setVisibility(View.VISIBLE);
        signupCard.setVisibility(View.INVISIBLE);
    }

    public void signup(View view){
        signupCard.setVisibility(View.VISIBLE);
        loginCard.setVisibility(View.INVISIBLE);
    }
}