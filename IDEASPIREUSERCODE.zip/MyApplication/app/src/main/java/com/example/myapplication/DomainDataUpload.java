package com.example.myapplication;

public class DomainDataUpload {

    private String DomainName;
    private String DomainImage;

    public void setKey(String key) {
        this.key = key;
    }

    private String key;
        int TotalProjects;

    public DomainDataUpload() {
    }

    public int getTotalProjects() {
        return TotalProjects;
    }


    public void setDomainName(String domainName) {
        DomainName = domainName;
    }

    public void setDomainImage(String domainImage) {
        DomainImage = domainImage;
    }

    public void setTotalProjects(int totalProjects) {
        TotalProjects = totalProjects;
    }

    public DomainDataUpload(String domainName, String domainImage) {
        this.DomainName = domainName;
        this.DomainImage = domainImage;
        this.key = key;
        this.TotalProjects = TotalProjects;
    }

    public String getDomainName() {
        return DomainName;
    }



    public String getDomainImage() {
        return DomainImage;
    }



    public String getKey() {
        return key;
    }


}
