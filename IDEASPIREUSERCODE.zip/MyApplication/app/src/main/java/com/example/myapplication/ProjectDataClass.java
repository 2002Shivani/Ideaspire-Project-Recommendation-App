package com.example.myapplication;


import java.util.Locale;

public class ProjectDataClass {

    private float rating;

    public ProjectDataClass(float total) {
        this.rating = total;
    }




    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }


    public ProjectDataClass( String projectTitle, String projectDescription,String authorName, String imageuri , String reportUrl ,String codeLink , String pptLink , String researchpaperLink1 ,float rating ) {
        this.authorName = authorName;
        this.imageuri = imageuri;
        this.projectTitle = projectTitle;
        this.projectDescription = projectDescription;
        this.reportLink = reportUrl;
        this.pptLink = pptLink;;
        this.codeLink = codeLink;
        this.researchpaperLink1 = researchpaperLink1;
        this.rating = rating;
        this.key = key;
    }


    public ProjectDataClass(String projectTitle, String projectDescription,String authorName,String category, String imageuri , String reportUrl ,String codeLink , String pptLink , String researchpaperLink1,float rating ) {
        Category = category;
        this.authorName = authorName;
        this.imageuri = imageuri;
        this.projectTitle = projectTitle;
        this.projectDescription = projectDescription;
        this.researchpaperLink1 = researchpaperLink1;
        this.pptLink = pptLink;
        this.reportLink = reportUrl;
        this.codeLink = codeLink;
        this.key = key;
        this.rating = rating;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    private String Category;
    public ProjectDataClass( String projectTitle, String projectDescription,String authorName, String imageuri , String reportUrl ,String codeLink , String pptLink , String researchpaperLink1  ) {
        this.authorName = authorName;
        this.imageuri = imageuri;
        this.projectTitle = projectTitle;
        this.projectDescription = projectDescription;
        this.reportLink = reportUrl;
        this.pptLink = pptLink;;
        this.codeLink = codeLink;
        this.researchpaperLink1 = researchpaperLink1;
        this.key = key;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getProjectDescription() {
        return projectDescription;
    }

    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    public String getResearchpaperLink1() {
        return researchpaperLink1;
    }

    public void setResearchpaperLink1(String researchpaperLink1) {
        this.researchpaperLink1 = researchpaperLink1;
    }

    public String getResearchpaperLink2() {
        return researchpaperLink2;
    }

    public void setResearchpaperLink2(String researchpaperLink2) {
        this.researchpaperLink2 = researchpaperLink2;
    }

    public String getPptLink() {
        return pptLink;
    }

    public void setPptLink(String pptLink) {
        this.pptLink = pptLink;
    }

    public String getReportLink() {
        return reportLink;
    }

    public void setReportLink(String reportLink) {
        this.reportLink = reportLink;
    }

    public String getCodeLink() {
        return codeLink;
    }

    public void setCodeLink(String codeLink) {
        this.codeLink = codeLink;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getImageuri() {
        return imageuri;
    }

    public void setImageuri(String imageuri) {
        this.imageuri = imageuri;
    }


    private String authorName,imageuri , projectTitle, projectDescription , researchpaperLink1 , researchpaperLink2 , pptLink ,reportLink,codeLink ,key;
    public ProjectDataClass(){

    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

//    public ProjectDataClass(String authorName , String imageuri , String projectTitle, String projectDescription, String researchpaperLink1, String researchpaperLink2, String pptLink, String reportLink, String codeLink) {
//        this.projectTitle = projectTitle;
//        this.projectDescription = projectDescription;
//        this.researchpaperLink1 = researchpaperLink1;
//        this.researchpaperLink2 = researchpaperLink2;
//        this.pptLink = pptLink;
//        this.reportLink = reportLink;
//        this.codeLink = codeLink;
//        this.imageuri = imageuri;
////        this.rating = rating;
//        this.authorName = authorName;
//        this.key = key;
//    }
}