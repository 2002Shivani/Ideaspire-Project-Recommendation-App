package com.example.myapplication;

public class RatingDataSave {

    public RatingDataSave(String projectTitle, float rating, float total) {
        this.projectTitle = projectTitle;
        this.rating = rating;
        this.total = total;
    }




    private String projectTitle , projectRater , Key;
    float rating;

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    float total;




    public RatingDataSave() {
    }

    public RatingDataSave(String projectTitle, float rating) {
        this.projectTitle = projectTitle;
        this.rating = rating;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}
