package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.example.myapplication.databinding.ActivityMainMenuBinding;

public class MainActivity extends AppCompatActivity {

     ActivityMainMenuBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent getDataFromLogin = getIntent();
        String UserName = getDataFromLogin.getStringExtra("username");
        String  Name = getDataFromLogin.getStringExtra("name");
        String Email = getDataFromLogin.getStringExtra("email");
        String Mobile = getDataFromLogin.getStringExtra("phone");
        String Type = getDataFromLogin.getStringExtra("type");
        String aboutme = getDataFromLogin.getStringExtra("aboutme");

//        Intent getDataFromEditProfile = getIntent();
//        String editUserName = getDataFromLogin.getStringExtra("username");
//        String  editName = getDataFromLogin.getStringExtra("name");
//        String editEmail = getDataFromLogin.getStringExtra("email");
//        String editMobile = getDataFromLogin.getStringExtra("phone");
//        String editType = getDataFromLogin.getStringExtra("type");

        binding = ActivityMainMenuBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        replaceFragment(new Home_fragment());

        binding.bottomNavigationView.setOnItemSelectedListener(item -> {

            int id = item.getItemId();

            if(id==R.id.home){
                replaceFragment(new Home_fragment());
            }
            else if(id==R.id.search){
                replaceFragment(new Search_fragment());
            }
            else if(id==R.id.idea){
                replaceFragment(new Idea_fragment());
            }
            else if(id==R.id.contactor){
                replaceFragment(new Contractor());
            }
            else if(id==R.id.profile){
                replaceFragment(Profile.getInstance(UserName,Name,Email,Mobile,Type,aboutme));

            }

            return true;
        });
    }

    private void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.framelayout,fragment);
        fragmentTransaction.commit();
    }


}