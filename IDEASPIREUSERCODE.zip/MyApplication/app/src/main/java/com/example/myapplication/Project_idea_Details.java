package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.clans.fab.FloatingActionButton;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

public class Project_idea_Details extends AppCompatActivity {
    TextView  projectTitleShow ,projectAuthorShow, projectDescriptionShow, baseStatus , reportStatus , pptStatus, codeStatus;
    ImageView projectImageShow;
    RatingBar ratingBarDialog;
    Button saveRating;
    Dialog uploadRating;
    MaterialButton rateProject , editProject;
    float RatingTotal;
    String key = "" , cardName ;
    String available = "Available" , notAvaliable = "Not Avaliable";
    String imageUrl = "" , pptUrl = "" , reportUrl = "",codeUrl = "" , baseUrl_1 = "" , baseUrl_2="";
    TextView ratingBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_idea_details);

        uploadRating = new Dialog(Project_idea_Details.this);
        uploadRating.setContentView(R.layout.rating_layout);
        if ( uploadRating.getWindow()!= null){
            uploadRating.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            uploadRating.setCancelable(true);
        };
        Intent getDataNameFromIdea  = getIntent();
        String CardDataName = getDataNameFromIdea.getStringExtra("CardName");
        rateProject = findViewById(R.id.rateProjectBtn);
        projectTitleShow  = findViewById(R.id.projectTitleShow);
        projectAuthorShow= findViewById(R.id.projectAuthorShow);
        projectDescriptionShow= findViewById(R.id.projectDescriptionShow);
        baseStatus = findViewById(R.id.basePaper);
        reportStatus = findViewById(R.id.reportStatus);
        pptStatus= findViewById(R.id.pptStatus);
        codeStatus= findViewById(R.id.codeStatus);
        ratingBarDialog = uploadRating.findViewById(R.id.ratingBar);
        saveRating = uploadRating.findViewById(R.id.ratingSave);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null){

            projectTitleShow.setText(bundle.getString("projectTitle"));
            projectAuthorShow.setText(bundle.getString("projectAuthor"));
            projectDescriptionShow.setText(bundle.getString("projectDescription"));
            key = bundle.getString("Key");
            pptUrl = bundle.getString("pptLink");
            reportUrl = bundle.getString("reportLink");
            codeUrl = bundle.getString("codeLink");
            baseUrl_1  = bundle.getString("basepaper1");
            baseUrl_2  = bundle.getString("basepaper2");
            cardName = bundle.getString("CardName");

            if(pptUrl==null||pptUrl.equals("NA")){
                pptStatus.setText(notAvaliable);
            }else {
                pptStatus.setText(available);
                pptStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        AlertDialog.Builder builder = new AlertDialog.Builder(Project_idea_Details.this);
                        builder.setMessage("Download PPT?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(pptUrl);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();


                    }
                });
            }

            if(reportUrl==null||reportUrl.equals("NA")){
                reportStatus.setText(notAvaliable);
            }else {
                reportStatus.setText(available);
                reportStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Project_idea_Details.this);
                        builder.setMessage("Download Report?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(reportUrl);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();

                    }
                });
            }


            if(codeUrl==null||codeUrl.equals("NA")){
                codeStatus.setText(notAvaliable);
            }else {
                codeStatus.setText(available);
                codeStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        AlertDialog.Builder builder = new AlertDialog.Builder(Project_idea_Details.this);
                        builder.setMessage("Download Source code?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(codeUrl);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();

                    }
                });
            }


            if(baseUrl_1==null||baseUrl_1.equals("NA")){
                baseStatus.setText(notAvaliable);
            }else {
                baseStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Project_idea_Details.this);
                        builder.setMessage("Download Base Paper?");
                        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                downloadFile(baseUrl_1);
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();
                    }
                });
            }

        }

        rateProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadRating.show();
            }
        });


        saveRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Project_idea_Details.this);
                builder.setCancelable(false);
                builder.setView(R.layout.progress_layout);
                AlertDialog dialog = builder.create();
                dialog.show();


                String title = projectTitleShow.getText().toString();
                float currentRating = ratingBarDialog.getRating();


                FirebaseDatabase.getInstance().getReference("Project Rating").child(title)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists()) {
                                    Float existingRating = snapshot.child("rating").getValue(Float.class);
                                    if (existingRating != null) {
                                        float newRating = existingRating + currentRating;
                                        float total = newRating/5.0f;
                                        saveRatingToDatabase(title, newRating,total);
                                        saveToMainProject(cardName,title,total);
                                        dialog.dismiss();
                                    }
                                }else {
                                    float total1 = currentRating/5.0f;
                                    saveRatingToDatabase(title, currentRating,total1);
                                    saveToMainProject(cardName,title,total1);
                                    dialog.dismiss();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast.makeText(Project_idea_Details.this ,error.getDetails(),Toast.LENGTH_LONG).show();
                                dialog.dismiss();
                            }
                        });



            }
        });


    }

    private void saveToMainProject(String CardName , String title, float total) {
        Map<String, Object> ratingUpdate = new HashMap<>();
        ratingUpdate.put("rating", total);

        // Get a reference to the database location you want to update
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference(CardName).child(title);

        // Update the specific child node
        databaseReference.updateChildren(ratingUpdate).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    // Rating value successfully updated
                    Toast.makeText(Project_idea_Details.this, "Rating value updated successfully", Toast.LENGTH_SHORT).show();
                } else {
                    // Failed to update rating value
                    Toast.makeText(Project_idea_Details.this, "Failed to update rating value", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void saveRatingToDatabase(String title, float newRating,float total) {
        RatingDataSave ratingDataSave = new RatingDataSave(title, newRating,total);
        FirebaseDatabase.getInstance().getReference("Project Rating").child(title)
                .setValue(ratingDataSave)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(Project_idea_Details.this, "Thank You", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Project_idea_Details.this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();

                    }
                });
    }

    private void downloadFile(String url) {
        if (!TextUtils.isEmpty(url)) {

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        }
    }






}