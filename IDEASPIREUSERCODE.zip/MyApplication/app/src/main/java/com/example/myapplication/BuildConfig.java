package com.example.myapplication;

public class BuildConfig {
    public static String apiKey = "AIzaSyCRdEXwdFINsEbwRL36PrLKBziyI-eLre4";
}
