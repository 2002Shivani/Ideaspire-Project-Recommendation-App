package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Upload_data_activity extends AppCompatActivity {
    EditText editFullName, editEmail, editUsername, editMobile , editAbout;
    Button saveButton;


    String nameUser, emailUser, usernameUser, mobileUser , aboutUser;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_data);
            reference = FirebaseDatabase.getInstance().getReference("Users");

            editFullName = findViewById(R.id.userFullnameU);
            editEmail = findViewById(R.id.EmailU);
            editUsername = findViewById(R.id.userNameU);
            editMobile = findViewById(R.id.MobileU);
            editAbout = findViewById(R.id.aboutMe);
            saveButton = findViewById(R.id.updateButton);



            showData();

        Log.d("msgUserName Edited", "Profile  is " + editUsername.getText().toString());
        Log.d("msgName Edited", "Profile is " + editFullName.getText().toString());
        Log.d("msgEmail Edited ", "Profile is " + editEmail.getText().toString());
        Log.d("msgMobile Edited", "Profile is " + editMobile.getText().toString());
        Log.d("Aboutme Edited", "Profile is " + editAbout.getText().toString());


            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isNameChanged() || isMobileChanged() || isEmailChanged()||isAboutmeChanged()){
                        Toast.makeText(Upload_data_activity.this, "Saved", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Upload_data_activity.this, "No Changes Found", Toast.LENGTH_SHORT).show();
                    }
                }



            });
        }

    private boolean isAboutmeChanged() {
        if (!aboutUser.equals(editAbout.getText().toString())){
            reference.child(usernameUser).child("aboutme").setValue(editAbout.getText().toString());
            aboutUser = editAbout.getText().toString();
            return true;
        } else {
            return false;
        }


    }

    private boolean isEmailChanged() {
        if (!emailUser.equals(editEmail.getText().toString())){
            reference.child(usernameUser).child("email").setValue(editEmail.getText().toString());
            emailUser = editEmail.getText().toString();
            return true;
        } else {
            return false;
        }
    }

    private boolean isMobileChanged() {
        if (!mobileUser.equals(editMobile.getText().toString())){
            reference.child(usernameUser).child("mobile").setValue(editMobile.getText().toString());
            mobileUser = editMobile.getText().toString();
            return true;
        } else {
            return false;
        }
    }

    private boolean isNameChanged() {
        if (!nameUser.equals(editFullName.getText().toString())){
            reference.child(usernameUser).child("name").setValue(editFullName.getText().toString());
            nameUser = editFullName.getText().toString();
            return true;
        } else {
            return false;
        }
    }


    public void showData(){
            Intent intent = getIntent();
            nameUser = intent.getStringExtra("Name");
            emailUser = intent.getStringExtra("Email");
            usernameUser = intent.getStringExtra("UserName");
            mobileUser =intent.getStringExtra("Mobile");
            aboutUser = intent.getStringExtra("About me");


//        intent.putExtra("UserName", username);
//        intent.putExtra("Name", fullname);
//        intent.putExtra("Email", Email);
//        intent.putExtra ("Mobile", Phone_no);
//        intent.putExtra ("UserType",  userType);
//        intent.putExtra("About me",des);

            editFullName.setText(nameUser);
            editEmail.setText(emailUser);
            editUsername.setText(usernameUser);
            editAbout.setText(aboutUser);
            editMobile.setText(mobileUser);



        }
    }


