package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {
    EditText userName ,name, Password;
    TextView SignUPText;
    Button LoginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userName = findViewById(R.id.LoginEmail);
        Password = findViewById(R.id.LoginPassword);
        LoginButton = findViewById(R.id.LoginBtn);
        SignUPText = findViewById(R.id.signupText);



        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validateUsername()|!validatePassword()){

                } else{
                    CheckUser();
                }
            }
        });
        SignUPText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(LoginActivity.this,SignUp.class);
                startActivity(intent);

            }
        });

    }

    public  Boolean validateUsername(){

        String val = userName.getText().toString();
        if(val.isEmpty()){
            userName.setError("Username Cannot be empty");
            return  false;
        }

        else{
            userName.setError(null);
            return  true;
        }
    }

    public  Boolean validatePassword(){

        String val = Password.getText().toString();
        if(val.isEmpty()){
            Password.setError("Password Cannot be empty");
            return  false;
        }

        else{
            userName.setError(null);
            return  true;
        }
    }

    public  void CheckUser(){
        String UsernameofUser = userName.getText().toString().trim();
        String PasswordOfUser = Password.getText().toString().trim();

        DatabaseReference  reference = FirebaseDatabase.getInstance().getReference("Users");
        Query checkUserDatabase = reference.orderByChild("username").equalTo(UsernameofUser);

        checkUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    userName.setError(null);
                    String passwordFromDB = snapshot.child( UsernameofUser).child("password").getValue(String.class);


                    //new added
                    String UsernameFromDB = snapshot.child( UsernameofUser).child("username").getValue(String.class);
                    String nameFromDB = snapshot.child( UsernameofUser).child("name").getValue(String.class);
                    String EmailFromDB = snapshot.child( UsernameofUser).child("email").getValue(String.class);
                    String MobileNoFromDB = snapshot.child( UsernameofUser).child("mobile").getValue(String.class);
                    String UserTypeFromDB = snapshot.child( UsernameofUser).child("userType").getValue(String.class);
                    String aboutMeDB =  snapshot.child( UsernameofUser).child("aboutme").getValue(String.class);
                    Log.d("msgUserName" , "Username is "+UsernameFromDB);
                    Log.d("msgName" , "Username is "+nameFromDB);
                    Log.d("msgEmail" , "Username is "+EmailFromDB);
                    Log.d("msgMobile" , "Username is "+MobileNoFromDB);
                    Log.d("msgType" , "Username is "+UserTypeFromDB);
                    Log.d("msgAboutme" , "Username is "+aboutMeDB);



                    if(passwordFromDB.equals(PasswordOfUser)){
//                      if(!Objects.equals(passwordFromDB,PasswordOfUser))
//                      {
                        userName.setError(null);
                        Toast.makeText(LoginActivity.this, "You Have login Successfully", Toast.LENGTH_SHORT).show();


                          Log.d("Password" , "Password is "+passwordFromDB);

                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.putExtra("username",UsernameofUser);
                        intent.putExtra("name",nameFromDB);
                        intent.putExtra("email",EmailFromDB);
                        intent.putExtra("phone",MobileNoFromDB);
                        intent.putExtra("type",UserTypeFromDB );
                        intent.putExtra("aboutme",aboutMeDB );
//                        HelperClass helperClass = new HelperClass();

        startActivity(intent);
        finish();


                    } else {
                        Password.setError("Inavlid Password");
                        Password.requestFocus();
                    }

                } else{
                    userName.setError("User does not exits");
                    userName.requestFocus();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println((error));
            }
        });




    }
}